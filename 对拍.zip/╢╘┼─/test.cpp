#include<iostream>
#include<vector>
#include <queue>
using namespace std;
#define int long long 
signed main(){
	ios::sync_with_stdio(0),cin.tie(0);
	int n;
	cin >> n;
	vector <int> a(n + 1);
	vector <int> suf(n + 5);
	for(int i=1;i<=n;i++){
		cin >> a[i];
	}
	
	int l = 0,r = 1e5;
	auto check = [&](int x){
		int sum = 0;
		for(int i = n;i>=1;i--){
			if(a[i] < x){
				int cha = x - a[i];
				if(sum < cha) return false;
				sum -= cha;
			}
			else{
				sum += a[i] - x;
			}
		}
		return true;
	};
	while(l + 1 < r){
		int mid = l + r >> 1;
		if(check(mid)) l = mid;
		else r= mid;
	}
	int ans = 0;
	priority_queue <int> q;
	for(int i=1;i<=n;i++){
		if(a[i] >l){
			if(q.size()==0){
				ans += i*(a[i] - l);
				a[i]=l;
			}
			else{
				while(q.size()){
					int x=q.top();
					q.pop();
					int cha = l - a[x];
					if(a[i] - l >= cha){
						a[x] = l;
						a[i]-=cha;
						ans+=(cha)*(i - x);
					}
					else{
						a[i] = l;
						a[x] += (a[i] - l);
						ans+=(a[i] - l)*(i - x);
						q.push(x);
						break;
					}
				}
				
			}
			if(a[i] > l){
				ans += i*(a[i] - l);
			}
		}
		if(a[i] < l){
			q.push(i);
		}
	}
	cout << ans << "\n";
	
	return 0;
}
