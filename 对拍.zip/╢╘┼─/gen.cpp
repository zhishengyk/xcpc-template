#include <iostream>
#include <random>
using namespace std;
mt19937_64 rng(random_device{}());
int random(int l, int r) {
	return rng() % (r - l + 1) + l;
}
int main(){
	
	int n = 10000;
	cout << n << "\n";
	for(int i=1;i<=n;i++){
		cout << random(-1e9,1e9) << " ";
	}
	return 0;
}
